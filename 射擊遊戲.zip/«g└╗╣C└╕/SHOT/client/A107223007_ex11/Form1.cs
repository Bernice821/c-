﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace A107223007_ex11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Socket T;
        Thread Th;
        string userName;
        bool invite = false;
        bool Xbang;
        int score1 = 0, score2 = 0;
        bool play = false;
		//連線登入
        private void button1_Click(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
            userName = textBox3.Text;
            string IP = textBox1.Text;
            int Port = int.Parse(textBox2.Text);
            try
            {
                IPEndPoint EP = new IPEndPoint(IPAddress.Parse(IP), Port);
                T = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                T.Connect(EP);
                Th = new Thread(Listen);
                Th.IsBackground = true;
                Th.Start();
                listBox2.Items.Add("已連線伺服器！");
                Send("0" + userName);
            }
            catch (Exception)
            {
                listBox2.Items.Add("無法連上伺服器！");
                return;
            }
            button1.Enabled = false;
            button2.Enabled = true;

        }
        private void Send(string Str)
        {
            byte[] B = Encoding.Default.GetBytes(Str);
            T.Send(B, 0, B.Length, SocketFlags.None);
        }
        private string MyIP()
        {
            string hn = Dns.GetHostName();
            IPAddress[] ip = Dns.GetHostEntry(hn).AddressList; //取得本機IP陣列
            foreach (IPAddress it in ip)
            {
                if (it.AddressFamily == AddressFamily.InterNetwork)
                {
                    return it.ToString();//如果是IPv4回傳此IP字串
                }
            }
            return ""; //找不到合格IP回傳空字串
        }
        private void Listen()
        {
            EndPoint ServerEP = (EndPoint)T.RemoteEndPoint;
            byte[] B = new byte[1023];
            int inLen = 0;
            string Msg;
            string St;
            string Str;
            while (true)
            {
                try
                {
                    inLen = T.ReceiveFrom(B, ref ServerEP);
                }
                catch (Exception)
                {
                    Send("9" + userName);
                    T.Close();
                    listBox1.Items.Clear();
                    listBox1.Items.Add("伺服器斷線了!");
                    button1.Enabled = true;
                    Th.Abort();
                }
                Msg = Encoding.Default.GetString(B, 0, inLen);
                listBox2.Items.Add(Msg);
                St = Msg.Substring(0, 1);
                Str = Msg.Substring(1);
                switch (St)
                {
                    case "3":
                        listBox2.Items.Add("使用者名稱" + Str + "重複");
                        T.Close();
                        listBox1.Items.Clear();
                        listBox2.Items.Add("伺服器斷線了！");
                        button1.Enabled = true;
                        Th.Abort();
                        continue;
						//上線的玩家
                    case "L":
                        listBox1.Items.Clear();
                        string[] M = Str.Split(',');
                        for (int i = 0; i < M.Length; i++)
                        {
                            listBox1.Items.Add(M[i]);
                        }
                        continue;
                    case "M":
                        listBox2.Items.Add(Str);
                        continue;
                }
                St = Msg.Substring(1, 1);
                Str = Msg.Substring(2);
                switch (St)
                {
                    case "3":
                        pictureBox1.Left = panel1.Width - int.Parse(Str) - pictureBox1.Width;
                        break;
                    case "4"://敵人開槍
                        Xbang = true; //樹立敵方開炮旗標
                        break;
                    case "I":
                        switch (Str)
                        {
							//重玩
                            case "Replay":
                                GameReload();
                                break;
								//玩家同意你的邀請
                            case "A":
                                play = true;
                                listBox1.Enabled = false;
                                invite = true;
                                MessageBox.Show(listBox1.SelectedItem + "同意您的邀請，可以開始遊戲");
                                button2.Enabled = false;
                                break;
								//玩家不同意你的邀請
                            case "U":
                                MessageBox.Show(listBox1.SelectedItem + "不同意您的邀請");
                                break;
                            default:
                                string[] c = Str.Split('|');
                                if (MessageBox.Show(c[0] + "邀請您玩射擊遊戲，是否接受?", "邀請訊息", MessageBoxButtons.YesNo) == DialogResult.Yes)
                                {
                                    int il = listBox1.Items.IndexOf(c[0]);
                                    listBox1.SetSelected(il, true);
                                    Send("2" + "IA" + "|" + listBox1.SelectedItem);
                                    listBox1.Enabled = false;
                                    button2.Enabled = false;
                                    play = true;
                                    invite = true;
                                }
                                else
                                {
                                    Send("2" + "IU" + "|" + c[0]);
                                }
                                break;
                        }
                        break;
                }
            }
        }
      //按下邀請玩家按鈕
        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                if (listBox1.SelectedItem.ToString() != userName)
                {
                    Send("2" + "I" + userName + "|" + listBox1.SelectedItem);
                }
                else
                {
                    MessageBox.Show("不可邀請自己!");
                }
            }
            else
            {
                MessageBox.Show("你沒有選取任何玩家!");
            }
        }
		//關閉遊戲視窗
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                Send("9" + userName);
                listBox1.Items.Clear();
                Th.Abort();
                T.Close();
                this.Close();
            }
            catch
            {

            }
        }
		//選擇離線
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                Send("9" + userName);
                listBox1.Items.Clear();
                Th.Abort();
                T.Close();
                this.Close();
            }
            catch
            {

            }
        }
		//按下重玩按鈕
        private void button3_Click(object sender, EventArgs e)
        {
            GameReload();
            Send("2" + "IReplay" + "|" + listBox1.SelectedItem);
        }
		//遊戲重新開始
        private void GameReload()
        {
            listBox2.Items.Clear();
            listBox2.Items.Add("遊戲重新");
            listBox2.Items.Add("請邀請玩家！");
            score1 = 0;
            score2 = 0;
            label6.Text = "我方得分:"+score1;
            label7.Text = "敵方得分:"+score2;
            play = true;
            button2.Enabled = true;
            invite = false;
            listBox1.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = MyIP(); //顯示IP
            button2.Enabled = false;
            button4.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            foreach (Control c in panel1.Controls)
            {
                string s = c.Tag.ToString();
                switch (s)
                {
                    case "B":
                        c.Top -= 5;
                        if (c.Bottom < 0) c.Dispose();
                        if (chkHit((Label)c, pictureBox1))
                        {
                            c.Dispose();
                            score1++;
                            label6.Text = "我方得分:" + score1;
                            if (score1 >= 5 && play == true)
                            {
                                listBox2.Items.Add("我方獲勝");
                                play = false;
                            }
                        }
                        break;
                    case "X":
                        c.Top += 5;
                        if (c.Top > panel1.Height) c.Dispose();
                        if (chkHit((Label)c, pictureBox2))
                        {
                            c.Dispose();
                            score2++;
                            label7.Text = "對方得分:" + score2;
                            if (score2 >= 5 && play == true)
                            {
                                listBox2.Items.Add("對方獲勝");
                                play = false;
                            }
                        }
                        break;
                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (Xbang)
            {
                Xshot();
                Xbang = false;
            }
        }

        private void Myshot()
        {
            Label B = new Label();
            B.Tag = "B";
            B.Width = 3;
            B.Height = 6;
            B.BackColor = Color.Red;
            B.Left = pictureBox2.Left + pictureBox2.Width / 2 - B.Width / 2;
            B.Top = pictureBox2.Top - B.Height;
            panel1.Controls.Add(B);
        }

        private void Xshot()
        {
            Label B = new Label();
            B.Tag = "X";
            B.Width = 3;
            B.Height = 6;
            B.BackColor = Color.Blue;
            B.Left = pictureBox1.Left + pictureBox1.Width / 2 - B.Width / 2;
            B.Top = pictureBox1.Top - B.Height;
            panel1.Controls.Add(B);
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            button2.Select();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (!(play && invite)) return;
            switch (e.KeyCode)
            {
                case Keys.Z: //往左
                    if (pictureBox2.Left < 5) return;
                    pictureBox2.Left -= 5;
                    break;
                case Keys.X: //往右
                    if (panel1.Width-pictureBox2.Right < 5) return;
                    pictureBox2.Left += 5;
                    break;
                case Keys.Space: //射擊
                    Myshot();
                    break;
            }
            if (listBox1.SelectedIndex >= 0)
            {
                switch (e.KeyCode)
                {
                    case Keys.Z:
                        Send("23" + pictureBox2.Left.ToString() + "|" + listBox1.SelectedItem);
                        break;
                    case Keys.X:
                        Send("23" + pictureBox2.Left.ToString() + "|" + listBox1.SelectedItem);
                        break;
                    case Keys.Space:
                        Send("24" + "S" + "|" + listBox1.SelectedItem);
                        break;
                }
                button2.Select();
            }

        }


        private bool chkHit(Label B, PictureBox C)
        {
            if (B.Right < C.Left) return false;
            if (B.Left > C.Right) return false;
            if (B.Bottom < C.Top) return false;
            if (B.Top > C.Bottom) return false;
            return true;
        }
    }
}
